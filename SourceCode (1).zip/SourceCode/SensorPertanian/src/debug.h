#include <Arduino.h>
#include "soil_data.h"

void info_soil_data(const SoilData& soilData);